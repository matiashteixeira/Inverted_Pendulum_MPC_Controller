% Cette fonction modifie le vecteur d'�tat du 
% syst�me lin�airis� afin de remplacer les angles 
% par leurs angles �quivalents compris entre 
% -pi et +pi 
function zm=z_mod(z)
    zm=zeros(5,1);
    zm(1)=z(1);
    zm(2)=angle_red(z(2));
    zm(3)=z(3);
    zm(4)=angle_red(z(4));
    zm(5)=z(5);
return