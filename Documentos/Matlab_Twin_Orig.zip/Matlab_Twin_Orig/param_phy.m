% Fichier de d�finition des param�tres physiques 

global alpha beta g
m0=2;               % Masse du chariot
m1=0.2;             % Masse du premier pendule
m2=0.1;             % Masse du deuxi�me pendule
el1=1;              % Longueur du premier pendule
el2=0.5;            % Longueur du deuxi�me pendule
I1=0.5*m1*el1^2;    % Moment d'inertie du premier pendule
I2=0.5*m2*el2^2;    % Moment d'inertie du deuxi�mes pendule
g=9.81;
% Noter que seules les inerties sont utilis�es 
% et non pas leurs d�pendance vis � vis des masses 
% et des longueurs exprim�es par les deux derni�res 
% relations. 
% Si des formes particuli�res des pendules sont 
% utilis�es, les deux derni�res relations ne sont
% plus valables et les inerties I1 et I2 doivent 
% �tre recalcul�es en fonction de la v�ritables 
% r�alisation des formes des pendules. 
%====================================================
% Calcul des param�tres des �quations du mouvement
alpha=zeros(2,1);
beta=zeros(2,1);
alpha(1)=m1*el1/(m1*el1^2+I1);
alpha(2)=m2*el2/(m2*el2^2+I2);
beta(1)=g*alpha(1);
beta(2)=g*alpha(2);
%====================================================
% D�finition des matrices du double integrateur 
% sous forme continue et disc�te
A_db=[0 1;0 0];
B_db=[0;1];
%====================================================



