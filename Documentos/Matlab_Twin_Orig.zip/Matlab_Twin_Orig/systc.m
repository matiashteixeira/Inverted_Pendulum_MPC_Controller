% fichier de d�finition du mod�le complet 
% x = (x_chariot;x_pendule1;x_pendule2)
% rd : consigne de position
% le syst�mes est d�fini � un param�tre pr�s qui 
% est la valeur de la commande v=acc�l�ration 
% du chariot

function xdot=systc(U)
    global alpha g 
    x=U(1:6);
    v=U(7);
    xdot=zeros(6,1);
    xdot(1)=x(2);
    xdot(2)=v;
    xdot(3)=x(4);
    xdot(4)=alpha(1)*(-cos(x(3))*v+g*sin(x(3)));
    xdot(5)=x(6);
    xdot(6)=alpha(2)*(-cos(x(5))*v+g*sin(x(5)));
return