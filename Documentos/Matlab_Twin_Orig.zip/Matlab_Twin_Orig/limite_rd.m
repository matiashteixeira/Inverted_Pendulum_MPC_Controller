% Cette fonction prend comme argument l'�tat du 
% syst�me complet. Elle calcule alors les limites 
% admissibles de la consigne en position de la 
% boucle de pr�compensation sur le chariot 
% pendant la phase de swing �tant donn� la position 
% actuelle et les limites des incr�ments et des but�es 
% virtuelles durant cette phase. 
function [rmin,rmax]=limite_rd(x)
    global dr_max g alpha E_max r_max eps_dr
    E1=0.5*x(4)^2+g*alpha(1)*(cos(x(3))-1);
    E2=0.5*x(6)^2+g*alpha(2)*(cos(x(5))-1);
    r=x(1);
    E=max(abs(E1/E_max(1)),abs(E2/E_max(2)));
    dr_potentiel=dr_max*E+eps_dr;
    rmin=max(-r_max,r-dr_potentiel);
    rmax=min(r_max,r+dr_potentiel);
return