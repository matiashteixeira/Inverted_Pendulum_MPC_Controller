% Cette fonction calcul un angle �quivalent 
% � son agrument d'entr�e et qui est contenu
% entre -pi et pi. 
function Ur=angle_red(U)
    N=fix(U/(2*pi));
    U=U-2*N*pi;
    Ur=U;
    if (U>pi),
        Ur=U-2*pi;
    elseif (U<-pi),
        Ur=2*pi+U;
    end
return
