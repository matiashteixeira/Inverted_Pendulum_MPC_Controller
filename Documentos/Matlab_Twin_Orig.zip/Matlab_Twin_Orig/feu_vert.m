% Cette fonction calcul la condition logique permettant ou non 
% de d�clanecher la commutation entre les deux contr�leurs 
% (pr�dictif et lin�aire local). 
% Plus pr�cis�ment, la commutation est activ�e si les deux 
% conditions suivantes sont remplies:
% La valeur de la fonction quadratique x^TSdx<=S_eps
% L'excursion pr�dite de la position du chariot reste dans la 
% zone admissible.
function oui=feu_vert(x)
    global Ad_BF tr1 ts r_max_2 S_eps
    xm=x;
    xm(3)=angle_red(x(3));
    xm(5)=angle_red(x(5));
    S=eval_S(xm);
    if (S>S_eps),
        oui=0;
    else
        N=fix(tr1/ts);
        [yy,xx] = dlsim([0 1 0 0 0 0;[zeros(5,1) Ad_BF]],zeros(6,1),[1 0 0 0 0 0],0,zeros(N,1),xm(1:6));
        rmax=max(abs(yy));
        if ((rmax<=r_max_2)&(abs(x(1))<=r_max_2)), 
            oui=1;
        else
            oui=0;
        end
    end
return