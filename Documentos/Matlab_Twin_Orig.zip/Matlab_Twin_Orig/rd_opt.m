% Cette fonction calcul la consigne optimale 
% de position du chariot durant la phase de swing-up 
% du syst�me. Il prend comme entr�e l'�tat du syst�me
% complet. Pour ce faire, l'�volution du syst�me est 
% pr�dite sur un horizon de pr�diction de longueur 
% T_pred et la valeur correspondante de la fonction E 
% est estim�e. La pr�diction est faite en lan�ant le 
% mod�le silumink intitul� "syst_precomp".
function rd=rd_opt(x)
    global T_pred x0_syst_precomp rd_syst_precomp
    les_cost=zeros(3,1);
    [rmin,rmax]=limite_rd(x);
    les_r=[rmin,x(1),rmax];
    x0_syst_precomp=x;
    for i=1:3,
        rd_syst_precomp=les_r(i);
        sim('syst_precomp');
        les_cost(i)=cost(end);
    end
    [cost,imin]=min(les_cost);
    rd=les_r(imin);
return