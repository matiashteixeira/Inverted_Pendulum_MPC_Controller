% Cette fonction calcul la forme quadratique � l'�tat 
% pr�sent comme argument d'entr�e. N�cessaire pour 
% �valuer la condition de commutation entre les contr�leur
% pr�dictif et lineaire local. 
function S=eval_S(x)
    global Sd
    z=x(2:6);
    z(2)=angle_red(z(2));
    z(4)=angle_red(z(4));
    S=(z'*Sd)*z;
return