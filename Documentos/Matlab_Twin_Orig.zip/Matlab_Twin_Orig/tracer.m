% Programme de trac� des r�sultats de la simulation en BF
close all
subplot(221),plot(tout,les_theta);grid on;
subplot(222),plot(tout,les_r,'black',tout,ones(size(tout))*r_max,tout,ones(size(tout))*r_max_2,...
    tout,-ones(size(tout))*r_max,tout,-ones(size(tout))*r_max_2);grid on;ylim([-1 1])
subplot(223),plot(T_sampled,lesE_BF(:,3));grid on;
subplot(224),stairs(T_sampled,les_v);grid on;ylim([-60,60]);
figure(gcf);
hold on;

%mov = avifile('sim10.avi')
nFrames = 20;
% Preallocate movie structure.
mov(1:nFrames) = struct('cdata', [],'colormap', []);

lim=max(el1,el2)*1.2;
L=0.2
tv=(0:ts:max(tout))';
n=length(tv);
lesxv=zeros(length(tv),6);
for i=1:6,
    lesxv(:,i)=interp1(tout,lesx(:,i),tv);
end
set(gcf,'Color','white')
set(gca,'FontSize',12);

figure(2)
for i=1:length(tv)-1,
   X1=[lesxv(i,1) lesxv(i,1)+el1*sin(lesxv(i,3))];
   Y1=[0 el1*cos(lesxv(i,3))];
   X2=[lesxv(i,1) lesxv(i,1)+el2*sin(lesxv(i,5))];
   Y2=[0 el2*cos(lesxv(i,5))];
   X3=[lesxv(i,1)-L/2 lesxv(i,1)-L/2 lesxv(i,1)+L/2 ...
       lesxv(i,1)+L/2 lesxv(i,1)-L/2];
   Y3=[-L/4 +L/4 +L/4 -L/4 -L/4];
   X4=[-r_max_2 -r_max_2];
   Y4=[-lim +lim];
   X5=[r_max_2 r_max_2];
   Y5=[-lim +lim];
   h=plot(X1,Y1,'r',X2,Y2,'b',[-lim lim],[0 0],'black',X3,Y3,'black',...
       X4,Y4,'r-.',X5,Y5,'r-.');axis equal;figure(gcf);
   set(h(1),'LineWidth',5)
   set(h(2),'LineWidth',5)
   set(h(3),'LineWidth',1)
   set(h(4),'LineWidth',5);
   set(gcf,'Color','black')
   xlim([-lim lim]);ylim([-lim lim])
   letexte=text(-lim+0.5,lim-0.5,['Time= ',num2str(tv(i)),' s']);
   set(letexte,'FontSize',18);
   pause(tv(end)/n);    
   mov(i)=getframe(gca);
   %mov=addframe(mov,M);
end
%movie2avi(mov, 'myPeaks.avi', 'compression', 'None');