load donnees

systeme=ss(A,[B zeros(5,5)],C,[D eye(2)]);
[Kest,L,P]=kalman(systeme,0.001*eye(5),eye(2),zeros(2,5));
