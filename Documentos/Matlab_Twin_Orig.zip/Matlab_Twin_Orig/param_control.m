% Fichier de calcul des param�tres du contr�leur
% Lancement du fichier de d�finition des param�tres physiques
clear all
param_phy;
%=============================================================
global ts dr_max tr dr_glob E_max r_max eps_dr r_max_2
global K_db_d Nts S1_d K_db T_pred Sd Ad_BF tr1 
global x0_syst_precomp rd_syst_precomp S_eps
ts=0.05;         % Temps d'�chantillonnage principal
tr=0.1;         % Temps du r�ponse du pr�-compensateur sur le chariot 
tr1=2;          % Temps de r�ponse du contr�leur local 
T_pred=tr+0.5;  % horizon de pr�diction pour la commande pr�dictive   
dr_max=0.3;     % incr�ment maximale du chariot 
r_max=0.4;      % But�es virtuelles du chariot pendant la phase 1
r_max_2=0.8;    % But�es virtuelles du chariot pendant la phase 2
eps_dr=0.1;   % terme de r�gularisation dans la relation entre 
                % l'incr�ment maximal de position et la valeur de 
                % la fonction de supervision E
%=============================================================
% Calcul du mod�le discr�tis� du double int�grateur 
% et du gain de la acompensation de la position du chariot
pole_db=-[1;1]*5/tr;
K_db=acker(A_db,B_db,pole_db);
[A_db_d,B_db_d]=c2d(A_db,B_db,ts);
pole_db_d=exp(-7*ts/tr*[1;1]);
K_db_d=acker(A_db_d,B_db_d,pole_db_d);
%==============================================================
% Calcul des niveaux maximal des 
% valeurs absolu des fonctions d'�nergie 
% E=0.5*thp^2+beta*(cos(th)-1)
E_max=2*g*alpha;
%==============================================================
% Matrice du syst�me dont l'�tat est 
% x=[drdt;theta1;dtheta1dt;theta2;dtheta2dt]
% et calcul du retour d'�tat final ainsi que 
% la matrice Sd de la forme quadratique 
% permettant de d�finir les conditions de commutation 
% entre les contr�leur ainsi que le seuil de 
% commutation S_eps$

A=[ 0 0 0 0 0;...
    0 0 1 0 0;...
    0 beta(1) 0 0 0;...
    0 0 0 0 1;...
    0 0 0 beta(2) 0];
B=[1;0;-alpha(1);0;-alpha(2)];
[Ad,Bd]=c2d(A,B,ts);
p_desires=exp(-15*ts/tr1*[1;1;1;1;1]);
Q=eye(5);R=1;
Kd=acker(Ad,Bd,p_desires);
%Kd=lqr(Ad,Bd,Q,R);
Ad_BF=Ad-Bd*Kd;
Sd=dlyap(Ad_BF',eye(5));
Sd=Sd/norm(Sd);
x_eps=[0;30*pi/180;0;30*pi/180;0];
S_eps=x_eps'*Sd*x_eps;
%===============================================================
% D�finition de l'�tat initial

x0=[0;0;180*pi/180;0.;180*pi/180;0];
%sim('syst_precomp_BF')

